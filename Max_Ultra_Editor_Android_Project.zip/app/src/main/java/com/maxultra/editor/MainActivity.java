package com.maxultra.editor;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 101;
    private static final int PICK_VIDEO = 102;
    private ImageView preview;
    private TextView status;
    private Bitmap original, working;
    private LinearLayout root, toolsPanel;
    private int accent = Color.rgb(139,92,246);
    private final List<String> photoTools = new ArrayList<>();
    private final List<String> videoTools = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildToolLists();
        showHome();
    }

    private void buildToolLists() {
        String[] p = {
            "Auto enhance","Max Ultra Enhance*","Brightness","Contrast","Saturation","Warmth",
            "Tint","Highlights","Shadows","Exposure","Sharpness","Denoise*","HDR look",
            "Crop*","Rotate","Flip horizontal","Flip vertical","Vignette","Blur*","Grayscale",
            "Sepia","Vintage","Cool tone","Warm tone","Black & white","Posterize",
            "Color pop*","Text overlay*","Watermark*","Resize*","Save / Export",
            "Max Eraser*","Background remover*","AI background replace*","Face-preserving retouch*"
        };
        String[] v = {
            "Video import","Trim*","Split*","Join clips*","Speed control*","Slow motion*",
            "Reverse*","Mute audio*","Volume*","Brightness","Contrast","Saturation",
            "Colour grading*","Stabilization*","Video denoise*","Video upscaling*",
            "AI object eraser*","AI background removal*","AI background replacement*",
            "Subject tracking*","Auto captions*","Text overlay*","Music overlay*",
            "Transitions*","Filters","Crop / rotate*","Aspect ratio*","Export video*"
        };
        for (String s:p) photoTools.add(s);
        for (String s:v) videoTools.add(s);
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private void pad(View v, int n) { v.setPadding(n,n,n,n); }
    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(bg(accent, 24));
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private void showHome() {
        root = column();
        root.setBackgroundColor(Color.rgb(11,11,18));
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = column(); pad(content, 20);
        TextView brand = text("MAX ULTRA", 13, Color.rgb(167,139,250));
        brand.setLetterSpacing(.16f);
        content.addView(brand);
        TextView title = text("Editor", 34, Color.WHITE);
        title.setTypeface(null, 1);
        content.addView(title);
        TextView sub = text("Photo + Video Studio  •  Android starter project", 13, Color.LTGRAY);
        content.addView(sub);
        TextView banner = text("\nMake every shot feel premium.\nKeep faces natural. Create your style.\n", 18, Color.WHITE);
        banner.setBackground(bg(Color.rgb(28,24,45), 28)); pad(banner, 20);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.topMargin=20;
        content.addView(banner,bp);

        LinearLayout actions = row();
        Button photo = button("＋  Edit Photo", () -> pick(PICK_IMAGE, "image/*"));
        Button video = button("▶  Edit Video", () -> pick(PICK_VIDEO, "video/*"));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0,-2,1); ap.setMargins(0,16,6,8);
        actions.addView(photo,ap);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(0,-2,1); vp.setMargins(6,16,0,8);
        actions.addView(video,vp);
        content.addView(actions);

        section(content, "PHOTO TOOLS", "35 tools planned", photoTools, true);
        section(content, "VIDEO TOOLS", "28 tools planned", videoTools, false);

        TextView note = text("\nIMPORTANT — Prototype status\nBasic photo adjustments work locally. Items marked * are UI/roadmap placeholders and need implementation or an AI service. Real face-preserving enhancement, generative erasing, realistic background replacement, video AI and export pipelines are not included yet. This app does not upload your media.", 13, Color.rgb(203,203,218));
        note.setBackground(bg(Color.rgb(25,25,36), 20)); pad(note,16);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2); np.topMargin=18;
        content.addView(note,np);
        scroll.addView(content); root.addView(scroll); setContentView(root);
    }

    private void section(LinearLayout parent, String title, String subtitle, List<String> tools, boolean photo) {
        TextView h = text(title, 18, Color.WHITE); h.setTypeface(null,1);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,-2); hp.topMargin=22;
        parent.addView(h,hp);
        parent.addView(text(subtitle,12,Color.rgb(165,165,183)));
        LinearLayout grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        for (int i=0;i<tools.size();i+=2) {
            LinearLayout r = row();
            for (int j=i;j<Math.min(i+2,tools.size());j++) {
                final String tool=tools.get(j);
                TextView tile = text(tool,13,Color.WHITE);
                tile.setBackground(bg(Color.rgb(27,27,40),18)); pad(tile,13);
                LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,-2,1);
                tp.setMargins(0,5,6,5);
                tile.setOnClickListener(v -> toolAction(tool, photo));
                r.addView(tile,tp);
            }
            if (tools.size()%2==1 && i+1>=tools.size()) {
                View blank=new View(this); r.addView(blank,new LinearLayout.LayoutParams(0,1,1));
            }
            grid.addView(r);
        }
        parent.addView(grid);
    }

    private void pick(int code, String type) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(type);
        try { startActivityForResult(i, code); }
        catch(Exception e) { Toast.makeText(this,"Could not open file picker",Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req,res,data);
        if (res!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        if (req==PICK_IMAGE) {
            try {
                InputStream in=getContentResolver().openInputStream(uri);
                Bitmap b=BitmapFactory.decodeStream(in); if(in!=null)in.close();
                if(b==null) throw new Exception("Unsupported image");
                original=b; working=b.copy(Bitmap.Config.ARGB_8888,true);
                showEditor();
            } catch(Exception e) { Toast.makeText(this,"Couldn't open this image",Toast.LENGTH_LONG).show(); }
        } else if(req==PICK_VIDEO) {
            new AlertDialogLike(this, "Video selected", "This starter project can pick a video, but editing/export and AI video tools still need implementation.").show();
        }
    }

    private void showEditor() {
        root=column(); root.setBackgroundColor(Color.rgb(11,11,18)); pad(root,16);
        LinearLayout top=row();
        TextView title=text("Photo Lab",24,Color.WHITE); title.setTypeface(null,1);
        top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        top.addView(button("← Home",()->showHome()));
        root.addView(top);
        preview=new ImageView(this); preview.setImageBitmap(working);
        preview.setAdjustViewBounds(true); preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,0,1); pp.setMargins(0,12,0,12);
        root.addView(preview,pp);
        status=text("Choose a local adjustment below.",12,Color.LTGRAY); root.addView(status);
        ScrollView s=new ScrollView(this); toolsPanel=column();
        addToolRow("Brightness −", "Brightness +", () -> adjust("brightness",-15), () -> adjust("brightness",15));
        addToolRow("Contrast −", "Contrast +", () -> adjust("contrast",-0.1f), () -> adjust("contrast",0.1f));
        addToolRow("Saturation −", "Saturation +", () -> adjust("saturation",-0.15f), () -> adjust("saturation",0.15f));
        addToolRow("Warm tone", "Cool tone", () -> adjust("warmth",10), () -> adjust("warmth",-10));
        addToolRow("Grayscale", "Sepia", () -> adjust("grayscale",1), () -> adjust("sepia",1));
        addToolRow("Reset", "Save image", () -> { working=original.copy(Bitmap.Config.ARGB_8888,true); refresh(); }, () -> saveImage());
        s.addView(toolsPanel); root.addView(s,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
    }

    private void addToolRow(String a, String b, Runnable ra, Runnable rb) {
        LinearLayout r=row();
        Button ba=button(a,ra), bb=button(b,rb);
        LinearLayout.LayoutParams x=new LinearLayout.LayoutParams(0,-2,1); x.setMargins(0,5,5,5);
        LinearLayout.LayoutParams y=new LinearLayout.LayoutParams(0,-2,1); y.setMargins(5,5,0,5);
        r.addView(ba,x); r.addView(bb,y); toolsPanel.addView(r);
    }

    private void adjust(String mode, float amount) {
        if (working==null) return;
        int w=working.getWidth(), h=working.getHeight();
        Bitmap src=working; Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        float sat=1f, contrast=1f, bright=0f, warm=0f;
        if(mode.equals("brightness")) bright=amount;
        if(mode.equals("contrast")) contrast=1f+amount;
        if(mode.equals("saturation")) sat=Math.max(0f,1f+amount);
        if(mode.equals("warmth")) warm=amount;
        if(mode.equals("grayscale")) sat=0f;
        if(mode.equals("sepia")) { sat=0.8f; warm=18f; contrast=1.05f; }
        float t=contrast, b=bright, sa=sat, wa=warm;
        int[] px=new int[w*h]; src.getPixels(px,0,w,0,0,w,h);
        for(int i=0;i<px.length;i++){
            int c=px[i]; float r=Color.red(c), g=Color.green(c), bl=Color.blue(c);
            float gray=0.299f*r+0.587f*g+0.114f*bl;
            r=gray+(r-gray)*sa; g=gray+(g-gray)*sa; bl=gray+(bl-gray)*sa;
            r=(r-128)*t+128+b+wa; g=(g-128)*t+128+b; bl=(bl-128)*t+128+b-wa;
            px[i]=Color.argb(Color.alpha(c),clamp(r),clamp(g),clamp(bl));
        }
        out.setPixels(px,0,w,0,0,w,h); working=out; refresh();
        status.setText("Applied "+mode+". Changes are local on this device.");
    }
    private int clamp(float x){return (int)Math.max(0,Math.min(255,x));}
    private void refresh(){ if(preview!=null) preview.setImageBitmap(working); }

    private void saveImage() {
        if(working==null)return;
        try {
            android.content.ContentValues values=new android.content.ContentValues();
            values.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,"MaxUltra_"+System.currentTimeMillis()+".jpg");
            values.put(android.provider.MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            Uri u=getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
            if(u==null)throw new Exception("Save location unavailable");
            OutputStream out=getContentResolver().openOutputStream(u);
            working.compress(Bitmap.CompressFormat.JPEG,95,out); out.close();
            status.setText("Saved to Photos/Gallery.");
            Toast.makeText(this,"Saved to Gallery",Toast.LENGTH_LONG).show();
        }catch(Exception e){Toast.makeText(this,"Save failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private void toolAction(String tool, boolean photo) {
        if (photo && original!=null && !tool.contains("*")) {
            switch(tool) {
                case "Brightness": adjust("brightness",15); return;
                case "Contrast": adjust("contrast",0.1f); return;
                case "Saturation": adjust("saturation",0.15f); return;
                case "Warmth": adjust("warmth",10); return;
                case "Grayscale": adjust("grayscale",1); return;
                case "Sepia": adjust("sepia",1); return;
                case "Save / Export": saveImage(); return;
            }
        }
        String msg = tool.contains("*")
            ? tool+" is planned but not implemented yet. It needs additional code and, for AI features, a compatible model/service."
            : tool+" is in the roadmap. Open a photo to use the working basic adjustment controls.";
        new AlertDialogLike(this,tool,msg).show();
    }

    private static class AlertDialogLike {
        private final Activity a; private final String title, message;
        AlertDialogLike(Activity a,String t,String m){this.a=a;title=t;message=m;}
        void show(){new android.app.AlertDialog.Builder(a).setTitle(title).setMessage(message)
            .setPositiveButton("OK",(d,w)->{}).show();}
    }
}
