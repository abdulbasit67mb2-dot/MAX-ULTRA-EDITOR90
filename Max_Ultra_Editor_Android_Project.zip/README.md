# Max Ultra Editor — Android starter project

A native Android Java starter project targeting Android 6+ (minSdk 23), suitable as a foundation for a Poco C51.

## What works in this starter
- Home screen with photo and video tool catalogues.
- Opens an image from the phone using Android's document picker.
- Basic local brightness, contrast, saturation, warm/cool tone, grayscale and sepia adjustments.
- Reset and save edited image to Gallery.
- Opens the video picker, with a clear notice that video editing is not implemented.

## Not implemented yet
The following are roadmap/UI placeholders, not functional AI features:
- Max Ultra AI enhance / face-preserving super-resolution
- AI denoise and detail reconstruction
- Max Eraser / object removal / inpainting
- Background segmentation, replacement, realistic shadows and relighting
- AI face retouch
- Video timeline, object eraser, video background removal/replacement, tracking, stabilisation, upscaling, captions, transitions and video export
- Many listed tools are catalogue entries only

These need actual algorithms or an AI model/service. A backend may be a hosted API (requires internet, cost, privacy policy and secure server-side key handling) or suitable on-device models (device storage/RAM/performance constraints). Never place secret API keys in the APK.

## Build APK
1. Open this folder as a project in Android Studio on a computer.
2. Install Android SDK Platform 35 and a compatible JDK (Android Studio bundled JDK is recommended).
3. Sync Gradle.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK usually appears at `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This environment has created the source project ZIP, not a compiled APK. You need Android Studio/Gradle to build the installable APK. For a phone-only workflow, use a trusted cloud build environment or an Android IDE that supports Gradle projects, and inspect any downloaded APK before installing.
